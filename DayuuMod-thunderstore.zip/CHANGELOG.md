1.0.2: Added 1 + 1 cards, Passer Secare no longer return to draw pile by played. Color the World should correctly stack it's buff. Updated cards description.  
1.0.1: Late Night Bites no longer try to discard exiled cards.  
1.0.0: Release.