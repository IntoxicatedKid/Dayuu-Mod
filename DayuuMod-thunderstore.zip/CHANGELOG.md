1.0.8: Updated to v1.3.18.  
1.0.7: Fixed Jade Box not working.  
1.0.6: Fixed Hexagon not working.  
1.0.5: New final boss: Hexagon. Added 1 Jade Box: Interdimensional Object.  
This Jade Box guarantees Hexagon to appear.  
1.0.4: Added 2 cards: Fantasy Spark, ??????(beta). Added 1 exhibit: Old Blank Card.  
Color the World reworked, gain 1 random mana by default, increased by 1(2) for each remnant or teammate card in the hand.  
1.0.3: Youkai Symposium draw 2 -> 3 cards. Fixed Color the World giving single color of mana.  
1.0.2: Added 1 + 1 cards. Passer Secare no longer return to draw pile by played. Color the World should correctly stack it's buff. Updated cards description.  
1.0.1: Late Night Bites no longer try to discard exiled cards.  
1.0.0: Release.