Adds 5+1 Dayuu cards, 1 Dayuu exhibit to the game. It's more of a joke, practice mod.  
You need LBoL-Entity-Sideloader to use this mod.

Installation(Github): Download DayuuMod.dll and place it to Steam\steamapps\common\LBoL\BepInEx\plugins

Credit:  
Lost Branch of Legend By Alioth Studio  
BepInEx by BepInEx  
LBoL-Entity-Sideloader by Neoshrimp#7746  
Dayuu by Dayuu
