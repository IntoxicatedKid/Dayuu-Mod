# Dayuu-Mod  
Adds 8+2 cards, 2 exhibits, 1 boss to the game. It's more of a joke, practice mod.  
You need LBoL-Entity-Sideloader to use this mod.

Credit:  
Lost Branch of Legend By Alioth Studio  
BepInEx by BepInEx  
LBoL-Entity-Sideloader by Neoshrimp#7746  
Dayuu by Dayuu
